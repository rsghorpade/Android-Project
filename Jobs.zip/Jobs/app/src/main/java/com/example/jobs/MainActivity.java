package com.example.jobs;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button buttonProfile, buttonJobs, buttonLogout, buttonCompanies, buttonAboutUs;
    private String userEmail; // To store user email

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonJobs = findViewById(R.id.buttonJobs);
        buttonLogout = findViewById(R.id.buttonLogout);
        buttonCompanies = findViewById(R.id.buttonCompanies);
        buttonAboutUs = findViewById(R.id.buttonAboutUs); // Added button for About Us

        // Retrieve email passed from LoginActivity
        Intent intent = getIntent();
        userEmail = intent.getStringExtra("USER_EMAIL");

        buttonJobs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("MainActivity", "Jobs button clicked");
                Intent intent = new Intent(MainActivity.this, JobsActivity.class);
                startActivity(intent);
            }
        });



        // Navigate to Companies Activity
        buttonCompanies.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CompaniesActivity.class);
                startActivity(intent);
            }
        });

        // Navigate to About Us Activity
        buttonAboutUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AboutUsActivity.class);
                startActivity(intent);
            }
        });

        // Logout the user and return to Login Activity
        buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish(); // Close the current activity
            }
        });
    }
}
