package com.example.jobs;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class JobApplicationActivity extends AppCompatActivity {

    private static final int PICK_RESUME_REQUEST = 1;

    private EditText etFullName, etEmail, etPhone, etExperience;
    private Button btnUploadResume, btnSubmit;
    private TextView tvResumeFile, tvJobTitle; // Add TextView for Job Title
    private Uri resumeUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_application);

        // Initialize the views
        etFullName = findViewById(R.id.et_full_name);
        etEmail = findViewById(R.id.et_email);
        etPhone = findViewById(R.id.et_phone);
        etExperience = findViewById(R.id.et_experience);
        btnUploadResume = findViewById(R.id.btn_upload_resume);
        btnSubmit = findViewById(R.id.btn_submit);
        tvResumeFile = findViewById(R.id.tv_resume_file);
        tvJobTitle = findViewById(R.id.tv_job_title); // Initialize Job Title TextView

        // Get the job title from the intent
        Intent intent = getIntent();
        String jobTitle = intent.getStringExtra("job_title");
        tvJobTitle.setText(jobTitle); // Display the job title

        // Set click listener for resume upload
        btnUploadResume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickResumeFile();
            }
        });

        // Set an onClickListener for the submit button
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fullName = etFullName.getText().toString();
                String email = etEmail.getText().toString();
                String phone = etPhone.getText().toString();
                String experience = etExperience.getText().toString();

                if (fullName.isEmpty() || email.isEmpty() || phone.isEmpty() || experience.isEmpty() || resumeUri == null) {
                    Toast.makeText(JobApplicationActivity.this, "Please fill all fields and upload resume", Toast.LENGTH_SHORT).show();
                } else {
                    // Save to database
                    DatabaseHelper db = new DatabaseHelper(JobApplicationActivity.this);
                    boolean inserted = db.insertApplication(fullName, email, phone, experience, resumeUri.toString(), jobTitle);

                    if (inserted) {
                        // Navigate to ThankYouActivity
                        Intent intent = new Intent(JobApplicationActivity.this, ThankYouActivity.class);
                        startActivity(intent);
                        finish(); // Close the current activity
                    } else {
                        Toast.makeText(JobApplicationActivity.this, "Failed to Submit Application", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


    }

    // Function to pick resume file
    private void pickResumeFile() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/pdf"); // We are assuming the resume is in PDF format
        startActivityForResult(intent, PICK_RESUME_REQUEST);
    }

    // Handle the result of the file picker
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_RESUME_REQUEST && resultCode == RESULT_OK && data != null) {
            resumeUri = data.getData();
            if (resumeUri != null) {
                String fileName = getFileName(resumeUri);
                tvResumeFile.setText(fileName);
            }
        }
    }

    // Helper method to get the file name from URI
    @SuppressLint("Range")
    private String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                }
            } finally {
                cursor.close();
            }
        }
        if (result == null) {
            result = uri.getPath();
            int cut = result.lastIndexOf('/');
            if (cut != -1) {
                result = result.substring(cut + 1);
            }
        }
        return result;
    }
}
