package com.example.jobs;
 // Change to your package name

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class FeedbackActivity extends AppCompatActivity {

    private EditText feedbackEditText;
    private Button submitButton ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        feedbackEditText = findViewById(R.id.feedback_edittext);
        submitButton = findViewById(R.id.submit_button);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String feedback = feedbackEditText.getText().toString().trim();
                if (!feedback.isEmpty()) {
                    // Handle the feedback submission (e.g., save it to the database or send it to a server)
                    Toast.makeText(FeedbackActivity.this, "Feedback submitted. Thank you!", Toast.LENGTH_SHORT).show();
                    // Optionally navigate to another activity
                    startActivity(new Intent(FeedbackActivity.this, MainActivity.class));
                    finish(); // Close this activity
                } else {
                    Toast.makeText(FeedbackActivity.this, "Please enter your feedback.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
