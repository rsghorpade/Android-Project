package com.example.jobs;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class CompaniesActivity extends AppCompatActivity {

    private ListView listViewCompanies;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_companies);

        // Initialize the ListView and DatabaseHelper
        listViewCompanies = findViewById(R.id.listViewCompanies);
        db = new DatabaseHelper(this);

        // Fetch the list of companies from the database
        ArrayList<String> companyList = db.getAllCompanies();  // Now returns ArrayList of company names

        // If no companies are found, show a message
        if (companyList.isEmpty()) {
            Toast.makeText(this, "No companies available", Toast.LENGTH_SHORT).show();
        } else {
            // Set the ListView with the data
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, companyList);
            listViewCompanies.setAdapter(adapter);
        }
    }
}
