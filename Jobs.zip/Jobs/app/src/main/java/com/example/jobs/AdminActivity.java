package com.example.jobs;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AdminActivity extends AppCompatActivity {

    // Declare the UI components
    private EditText editTextCompanyName, editTextCompanyDescription;
    private Button buttonAddCompany, buttonGoToMain; // Added button for navigating to the main page
    private DatabaseHelper db;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin); // Ensure this layout exists

        // Initialize the DatabaseHelper
        db = new DatabaseHelper(this);

        // Initialize UI components
        editTextCompanyName = findViewById(R.id.editTextCompanyName);
        editTextCompanyDescription = findViewById(R.id.editTextCompanyDescription);
        buttonAddCompany = findViewById(R.id.buttonAddCompany);
        buttonGoToMain = findViewById(R.id.buttonGoToMain); // Initialize the button to go to the main page

        // Set the click listener for the "Add Company" button
        buttonAddCompany.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String companyName = editTextCompanyName.getText().toString().trim();
                String companyDescription = editTextCompanyDescription.getText().toString().trim();

                // Validate input fields
                if (companyName.isEmpty() || companyDescription.isEmpty()) {
                    Toast.makeText(AdminActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Insert company details into the database
                    boolean insert = db.insertCompany(companyName, companyDescription);
                    if (insert) {
                        Toast.makeText(AdminActivity.this, "Company Added Successfully", Toast.LENGTH_SHORT).show();
                        // Optionally, clear the fields after adding
                        editTextCompanyName.setText("");
                        editTextCompanyDescription.setText("");

                        Intent intent = new Intent(AdminActivity.this, CompaniesActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(AdminActivity.this, "Failed to Add Company", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // Set the click listener for the "Go to Main Page" button
        buttonGoToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate to MainActivity
                Intent intent = new Intent(AdminActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // Close AdminActivity if desired
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        db.close(); // Close the database to prevent memory leaks
    }
}
