package com.example.jobs;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Name and Version
    private static final String DATABASE_NAME = "UserDatabase.db";
    private static final int DATABASE_VERSION = 12; // Updated database version for changes

    // Table Names
    private static final String TABLE_USERS = "Users";
    private static final String TABLE_JOBS = "Jobs";
    private static final String TABLE_COMPANIES = "Companies";
    private static final String TABLE_JOB_APPLICATIONS = "job_applications";

    // User Table Columns
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_NAME = "Name";
    public static final String COLUMN_SURNAME = "Surname";
    public static final String COLUMN_EMAIL = "Email";
    public static final String COLUMN_CONTACT_NUMBER = "ContactNumber";
    public static final String COLUMN_GENDER = "Gender";
    public static final String COLUMN_PASSWORD = "Password";
    public static final String COLUMN_ROLE = "Role";

    // Job Table Columns
    public static final String COLUMN_JOB_ID = "JobID";
    public static final String COLUMN_JOB_TITLE = "JobTitle";
    public static final String COLUMN_JOB_DESCRIPTION = "JobDescription";
    public static final String COLUMN_COMPANY_NAME = "CompanyName";

    // Company Table Columns
    public static final String COLUMN_COMPANY_ID = "CompanyID";
    public static final String COLUMN_COMPANY_DESCRIPTION = "CompanyDescription";

    // SQL queries to create tables
    private static final String CREATE_TABLE_USERS = "CREATE TABLE " + TABLE_USERS + " (" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_NAME + " TEXT, " +
            COLUMN_SURNAME + " TEXT, " +
            COLUMN_EMAIL + " TEXT UNIQUE, " +
            COLUMN_CONTACT_NUMBER + " TEXT, " +
            COLUMN_GENDER + " TEXT, " +
            COLUMN_PASSWORD + " TEXT, " +
            COLUMN_ROLE + " TEXT)";

    private static final String CREATE_TABLE_COMPANIES = "CREATE TABLE " + TABLE_COMPANIES + " (" +
            COLUMN_COMPANY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_COMPANY_NAME + " TEXT UNIQUE, " +
            COLUMN_COMPANY_DESCRIPTION + " TEXT)";

    private static final String CREATE_TABLE_JOBS = "CREATE TABLE " + TABLE_JOBS + " (" +
            COLUMN_JOB_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_JOB_TITLE + " TEXT, " +
            COLUMN_JOB_DESCRIPTION + " TEXT, " +
            COLUMN_COMPANY_NAME + " TEXT, " +
            "FOREIGN KEY(" + COLUMN_COMPANY_NAME + ") REFERENCES " + TABLE_COMPANIES + "(" + COLUMN_COMPANY_NAME + "))";

    private static final String CREATE_TABLE_JOB_APPLICATIONS = "CREATE TABLE " + TABLE_JOB_APPLICATIONS + " (" +
            "ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "full_name TEXT, " +
            "email TEXT, " +
            "phone TEXT, " +
            "experience TEXT, " +
            "resume_uri TEXT, " +
            "job_title TEXT)";


    // Constructor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_COMPANIES);
        db.execSQL(CREATE_TABLE_JOBS);
        db.execSQL(CREATE_TABLE_JOB_APPLICATIONS); // Add this line
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COMPANIES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_JOBS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_JOB_APPLICATIONS); // Add this line
        onCreate(db);
    }

    // User Operations
    public boolean insertUser(String name, String surname, String email, String contactNumber, String gender, String password, String role) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_SURNAME, surname);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_CONTACT_NUMBER, contactNumber);
        values.put(COLUMN_GENDER, gender);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_ROLE, role);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COLUMN_ID + " FROM " + TABLE_USERS + " WHERE " + COLUMN_EMAIL + " = ? AND " + COLUMN_PASSWORD + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{email, password});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    // Company Operations
    public boolean insertCompany(String companyName, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_COMPANY_NAME, companyName);
        values.put(COLUMN_COMPANY_DESCRIPTION, description);

        long result = db.insert(TABLE_COMPANIES, null, values);
        return result != -1;
    }

    public ArrayList<String> getAllCompanies() {
        ArrayList<String> companies = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_COMPANY_NAME + " FROM " + TABLE_COMPANIES, null);

        if (cursor.moveToFirst()) {
            do {
                companies.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return companies;
    }

    // Job Operations
    public boolean insertJob(String jobTitle, String companyName, String jobDescription) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_JOB_TITLE, jobTitle);
        values.put(COLUMN_COMPANY_NAME, companyName);
        values.put(COLUMN_JOB_DESCRIPTION, jobDescription);

        long result = db.insert(TABLE_JOBS, null, values);
        return result != -1;
    }

    // Get user details by email
    public Cursor getUserByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_NAME, COLUMN_SURNAME, COLUMN_EMAIL, COLUMN_CONTACT_NUMBER, COLUMN_GENDER, COLUMN_ROLE};
        String selection = COLUMN_EMAIL + " = ?";
        String[] selectionArgs = {email};

        // Query the database
        return db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
    }

    public boolean updateUserProfile(String email, String name, String surname, String contactNumber, String gender) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        // Add updated values to ContentValues
        contentValues.put(COLUMN_NAME, name);
        contentValues.put(COLUMN_SURNAME, surname);
        contentValues.put(COLUMN_CONTACT_NUMBER, contactNumber);
        contentValues.put(COLUMN_GENDER, gender);

        // Update the user profile based on email
        int rowsAffected = db.update(
                TABLE_USERS, // Replace with your actual table name
                contentValues,
                COLUMN_EMAIL + " = ?", // Update condition
                new String[]{email} // Arguments for the condition
        );

        // Return true if at least one row was updated
        return rowsAffected > 0;
    }

    public ArrayList<JobsActivity.Job> getAllJobs() {
        ArrayList<JobsActivity.Job> jobList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_JOB_TITLE + ", " + COLUMN_COMPANY_NAME + " FROM " + TABLE_JOBS, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex(COLUMN_JOB_TITLE));
                @SuppressLint("Range") String company = cursor.getString(cursor.getColumnIndex(COLUMN_COMPANY_NAME));
                jobList.add(new JobsActivity.Job(title, company));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return jobList;
    }

    public ArrayList<String> getJobsByCompany(String companyName) {
        ArrayList<String> jobs = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_JOB_TITLE + " FROM " + TABLE_JOBS + " WHERE " + COLUMN_COMPANY_NAME + " = ?", new String[]{companyName});

        if (cursor.moveToFirst()) {
            do {
                jobs.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return jobs;
    }
    // DatabaseHelper.java
    public boolean insertApplication(String fullName, String email, String phone, String experience, String resumeUri, String jobTitle) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("full_name", fullName);
        contentValues.put("email", email);
        contentValues.put("phone", phone);
        contentValues.put("experience", experience);
        contentValues.put("resume_uri", resumeUri);
        contentValues.put("job_title", jobTitle);

        try {
            long result = db.insert(TABLE_JOB_APPLICATIONS, null, contentValues);
            if (result == -1) {
                Log.e("DB_ERROR", "Failed to insert application.");
                return false;
            }
            return true;
        } catch (Exception e) {
            Log.e("DB_EXCEPTION", e.getMessage());
            return false;
        }
    }
}
