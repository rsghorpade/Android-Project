package com.example.jobs;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class JobsActivity extends AppCompatActivity {

    private ListView jobListView;
    private ArrayList<Job> jobList;
    private DatabaseHelper db;
    private ArrayAdapter<Job> adapter;

    // Job class to represent job details
    public static class Job {
        private String title;
        private String company;

        // Constructor
        public Job(String title, String company) {
            this.title = title;
            this.company = company;
        }

        public String getTitle() {
            return title;
        }

        public String getCompany() {
            return company;
        }

        @Override
        public String toString() {
            return title + " @ " + company;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jobs);

        // Initialize the ListView and DatabaseHelper
        jobListView = findViewById(R.id.job_list_view);
        db = new DatabaseHelper(this);

        // Initialize job list
        jobList = new ArrayList<>();

        // Set up the ArrayAdapter with a custom layout for ListView
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, jobList);
        jobListView.setAdapter(adapter);

        // Fetch job data from the database asynchronously
        new LoadJobsTask().execute();

        // Set an item click listener for the ListView
        jobListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Start JobApplicationActivity and pass the job details
                Intent intent = new Intent(JobsActivity.this, JobApplicationActivity.class);
                intent.putExtra("job_title", jobList.get(position).getTitle());
                intent.putExtra("company_name", jobList.get(position).getCompany());
                startActivity(intent);
            }
        });

        // Retrieve the job data passed from CompanyActivity
        Intent intent = getIntent();
        String companyName = intent.getStringExtra("company_name");
        String jobTitle = intent.getStringExtra("job_title");
        String jobDescription = intent.getStringExtra("job_description");

        // If job data is passed, create a new Job object and add it to the list
        if (companyName != null && jobTitle != null) {
            jobList.add(new Job(jobTitle, companyName));
            adapter.notifyDataSetChanged();  // Update the ListView
        }
    }

    private class LoadJobsTask extends AsyncTask<Void, Void, ArrayList<Job>> {

        @Override
        protected ArrayList<Job> doInBackground(Void... voids) {
            try {
                return db.getAllJobs();  // Fetch the job data from the database
            } catch (Exception e) {
                Log.e("JobsActivity", "Error fetching jobs: " + e.getMessage());
                return null;
            }
        }

        @Override
        protected void onPostExecute(ArrayList<Job> jobs) {
            if (jobs != null && !jobs.isEmpty()) {
                jobList.clear(); // Clear existing data
                jobList.addAll(jobs); // Add the fetched jobs
                adapter.notifyDataSetChanged(); // Notify the adapter to update the ListView
            } else {
                Log.e("JobsActivity", "No jobs found or failed to load jobs.");
            }
        }
    }
}
