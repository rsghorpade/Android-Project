package com.example.jobs;
// Change to your actual package name

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ThankYouActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thank_you); // Ensure this matches your XML file name

        // Set up the thank you message
        TextView thankYouMessage = findViewById(R.id.thank_you_message);

        // Retrieve feedback from intent
        Intent intent = getIntent();
        String feedback = intent.getStringExtra("USER_FEEDBACK"); // Get the passed feedback

        if (feedback != null) {
            thankYouMessage.setText("Thank you for Applying: " + feedback); // Display the feedback
        } else {
            thankYouMessage.setText("Thank you for Applying!");
        }

        // Set up the button to return to FeedbackActivity
        Button feedbackButton = findViewById(R.id.feedback_button);
        feedbackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an intent to start FeedbackActivity
                Intent intent = new Intent(ThankYouActivity.this, FeedbackActivity.class);
                startActivity(intent);
                finish(); // Close ThankYouActivity
            }
        });
    }
}
