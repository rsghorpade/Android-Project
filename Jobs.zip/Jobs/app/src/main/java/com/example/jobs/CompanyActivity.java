package com.example.jobs;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CompanyActivity extends AppCompatActivity {

    private EditText editCompanyName, editJobTitle, editJobDescription;
    private Button btnAddJob, btnGoToMain;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company);

        // Initialize views
        editCompanyName = findViewById(R.id.editCompanyName);
        editJobTitle = findViewById(R.id.editJobTitle);
        editJobDescription = findViewById(R.id.editJobDescription);
        btnAddJob = findViewById(R.id.btnAddJob);
        btnGoToMain = findViewById(R.id.btnGoToMain);

        // Set up the button click listener to add a job
        btnAddJob.setOnClickListener(new View.OnClickListener() {  // Corrected here
            @Override
            public void onClick(View v) {
                String companyName = editCompanyName.getText().toString().trim();
                String jobTitle = editJobTitle.getText().toString().trim();
                String jobDescription = editJobDescription.getText().toString().trim();

                if (companyName.isEmpty() || jobTitle.isEmpty() || jobDescription.isEmpty()) {
                    Toast.makeText(CompanyActivity.this, "All fields are required", Toast.LENGTH_SHORT).show();
                } else {
                    DatabaseHelper db = new DatabaseHelper(CompanyActivity.this); // Ensure DatabaseHelper is initialized
                    boolean isInserted = db.insertJob(jobTitle, companyName, jobDescription);
                    if (isInserted) {
                        Toast.makeText(CompanyActivity.this, "Job added successfully", Toast.LENGTH_SHORT).show();
                        editCompanyName.setText("");
                        editJobTitle.setText("");
                        editJobDescription.setText("");

                        Intent intent = new Intent(CompanyActivity.this, JobsActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(CompanyActivity.this, "Failed to add job", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // Set up the button click listener to go to MainActivity
        btnGoToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to MainActivity
                Intent intent = new Intent(CompanyActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // Optionally finish the current activity to prevent back navigation to it
            }
        });
    }
}
